import React from 'react';
import Hero from './components/Hero';
import BubbleGallery from './components/BubbleGallery';
import Messages from './components/Messages';
import Timeline from './components/Timeline';
import Encouragement from './components/Encouragement';
import Closing from './components/Closing';
import FloatingBubbles from './components/FloatingBubbles';

function App() {
  return (
    <div className="relative min-h-screen bg-gradient-to-br from-pink-50 via-rose-50 to-pink-100 overflow-x-hidden">
      <FloatingBubbles />
      <Hero />
      <BubbleGallery />
      <Messages />
      <Timeline />
      <Encouragement />
      <Closing />
    </div>
  );
}

export default App;