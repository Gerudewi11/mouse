import fs from 'fs';
import path from 'path';

// Read the built files
const htmlContent = fs.readFileSync('dist/index.html', 'utf-8');
const cssFiles = fs.readdirSync('dist/assets').filter(file => file.endsWith('.css'));
const jsFiles = fs.readdirSync('dist/assets').filter(file => file.endsWith('.js'));

let finalHtml = htmlContent;

// Inline CSS
cssFiles.forEach(cssFile => {
  const cssContent = fs.readFileSync(`dist/assets/${cssFile}`, 'utf-8');
  finalHtml = finalHtml.replace(
    `<link rel="stylesheet" crossorigin href="/assets/${cssFile}">`,
    `<style>${cssContent}</style>`
  );
});

// Inline JS
jsFiles.forEach(jsFile => {
  const jsContent = fs.readFileSync(`dist/assets/${jsFile}`, 'utf-8');
  finalHtml = finalHtml.replace(
    `<script type="module" crossorigin src="/assets/${jsFile}"></script>`,
    `<script type="module">${jsContent}</script>`
  );
});

// Clean up any remaining asset references
finalHtml = finalHtml.replace(/\/assets\//g, '');

// Write the single file
fs.writeFileSync('romantic-website.html', finalHtml);
console.log('✅ Single file created: romantic-website.html');